I used Google Colab.
You should change the data paths in nb.py in order to get the data.

Please run:

python3 nb.py


and:

python3 hmm.py

(This can take ~5 min to finish)

Thank you for all the efforts/help for us during all the Fall semester.